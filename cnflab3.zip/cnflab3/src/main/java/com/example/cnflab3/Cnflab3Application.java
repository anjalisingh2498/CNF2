package com.example.cnflab3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cnflab3Application {

	public static void main(String[] args) {
		SpringApplication.run(Cnflab3Application.class, args);
	}

}
