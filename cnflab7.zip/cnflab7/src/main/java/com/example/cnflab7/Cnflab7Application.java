package com.example.cnflab7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cnflab7Application {

	public static void main(String[] args) {
		SpringApplication.run(Cnflab7Application.class, args);
	}

}
