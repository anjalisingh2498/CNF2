package com.example.cnflab1;

public class Ticket {
	int tickno,price,seatno;
	public int getTickno() {
		return tickno;
	}
	public void setTickno(int tickno) {
		this.tickno = tickno;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getSeatno() {
		return seatno;
	}
	public void setSeatno(int seatno) {
		this.seatno = seatno;
	}
	public String getTicktype() {
		return ticktype;
	}
	public void setTicktype(String ticktype) {
		this.ticktype = ticktype;
	}
	String ticktype;
	

}
