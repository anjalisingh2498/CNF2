package com.example.fourth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FourthApplicationTests {

	@Test
	void contextLoads() {
	}

}
