package com.example.fourth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FourthApplication {

	public static void main(String[] args) {
		SpringApplication.run(FourthApplication.class, args);
	}

}
